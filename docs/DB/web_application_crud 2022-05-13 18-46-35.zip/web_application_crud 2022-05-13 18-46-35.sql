-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para web_application_crud
CREATE DATABASE IF NOT EXISTS `web_application_crud` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `web_application_crud`;

-- Volcando estructura para tabla web_application_crud.employees
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `identification` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `document` (`identification`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla web_application_crud.employees: ~8 rows (aproximadamente)
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`id`, `email`, `identification`, `name`, `surname`, `title`, `address`, `phone`, `photo`, `active`, `create_time`, `update_time`) VALUES
	(1, 'davezugezi@mailinator.com', '12546798', 'Akeem Sims', 'Kerr', 'Magna quidem quos ob', 'Consequatur optio n', '+1 (884) 285-4708', '73d891661cbb13cd21b198de6b3b4150.jpg', 1, '2022-03-28 20:16:31', NULL),
	(2, 'waxetili@mailinator.com', '546987321', 'Demetrius Mcfarland', 'Saunders', 'Earum sunt vel dolo', 'Reprehenderit ratio', '+1 (611) 615-6213', '73d891661cbb13cd21b198de6b3b4150.jpg', 1, '2022-03-28 20:51:34', NULL),
	(3, 'giji@mailinator.com', '5479832', 'Audra Bennett', 'Petty', 'Eius anim quaerat et', 'Aliquip totam unde a', '+1 (942) 431-9375', '73d891661cbb13cd21b198de6b3b4150.jpg', 1, '2022-03-28 20:58:51', NULL),
	(4, 'afgarzonca@unadvirtual.edu.co', '231546897', 'Andres', 'GarzÃ³n', 'Developer', 'Calle 1', '213456789', 'ajGqzG1n_700w_0.jpg', 1, '2022-03-28 21:10:02', NULL),
	(5, 'poke@mailinator.com', '13123123123', 'Troy Hays', 'Hurst', 'Administrator', 'Street 2', '+1 (995) 675-1116', 'ajGqzG1n_700w_0.jpg', 0, '2022-05-13 16:38:50', NULL),
	(6, 'zubepexa@mailinator.com', '21123564789', 'Steel Rogers', 'Rowe', 'Employee', 'Street 4 ', '+1 (597) 567-6703', '', 0, '2022-05-13 17:47:37', NULL),
	(7, 'catehogo@mailinator.com', '123465487978', 'Jemima ', 'Herrera', 'Designer Senior', 'Street 8 avenue', '+1 (433) 211-8888', '', 0, '2022-05-13 17:58:29', NULL),
	(8, 'pures@mailinator.com', '213456897', 'Eric', 'Baldwin', 'Administrator Senior', 'Praesentium 235 Avenue', '+1 (644) 355-6779', '', 0, '2022-05-13 18:27:04', NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
